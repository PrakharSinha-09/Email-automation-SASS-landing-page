if (!localStorage.getItem("loggedInUser")) {
    window.location.href = "index.html"; // Redirect to login
}

const isAdmin = localStorage.getItem("isAdmin") === "true";

if (!isAdmin) {
    alert("Access Denied: You are not an admin.");
    window.location.href = "home.html"; // Redirect to home
}

// function logout() {
//     localStorage.removeItem("loggedInUser");
//     localStorage.removeItem("isAdmin");
//     window.location.href = "index.html";
// }
